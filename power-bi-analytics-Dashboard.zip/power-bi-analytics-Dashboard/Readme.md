# HR Analytics Dashboard – Power BI

## 📊 Project Overview
This project analyzes employee attrition using Power BI.

The dashboard helps identify:
- employee turnover trends
- overtime impact
- department attrition
- age-group analysis
- workforce insights

---

## 🔧 Tools Used
- Power BI
- Excel / CSV Dataset

---

## 📈 Dashboard Features
- KPI Cards
- Attrition Analysis
- Overtime Analysis
- Age Group Analysis
- Interactive Filters/Slicers

---

## 💡 Key Insights
- Employees working overtime showed higher attrition
- Younger employees had higher turnover
- Sales department experienced the highest attrition

---

## 📷 Dashboard Preview
(Add screenshot here)
